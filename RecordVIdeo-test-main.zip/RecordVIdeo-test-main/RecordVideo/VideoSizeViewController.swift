//
//  VideoSizeViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit

/// 获取视频文件大小
class VideoSizeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "获取视频文件大小", style: .done, target: self, action: #selector(getVideoSize))
    }
    
    //MARK: 获取视频文件大小//文件属性
    @objc func getVideoSize() {
        
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619172935.mp4"

        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: videoPath) {
            let fileDic = try! fileManager.attributesOfItem(atPath: videoPath)
            print("文件属性")
            print(fileDic)
            let size = fileDic[FileAttributeKey(rawValue: "NSFileSize")] as? Int ?? 0
            print("\(size)B")
            print("\(size/1024)KB")
            let sizeM = String(format: "%.2f", Float(size)/1024/1024)
            print(sizeM + "M")
            
        }else{
            print("文件不存在")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
