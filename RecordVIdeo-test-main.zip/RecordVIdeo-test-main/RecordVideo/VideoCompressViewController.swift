//
//  VideoCompressViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit
import  AVFoundation


/// 视频压缩/转码
class VideoCompressViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "开始压缩", style: .done, target: self, action: #selector(starConvert))
    }
    
    @objc func starConvert() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619331826.mp4"
        
        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        
        
        print("==> 源文件")
        self.getVideoSize(videoUrl: URL(fileURLWithPath: videoPath))
        self.getVideoLength(videoUrl: URL(fileURLWithPath: videoPath))
        
        print("==> 开始压缩/转码")
        let outputPath = self.getNewPath(videoTyle: AVFileType.mov)
        
        self.convertVideo(inputURL: URL(fileURLWithPath: videoPath),
                          outputURL: URL(fileURLWithPath: outputPath),
                          presetName: AVAssetExportPresetMediumQuality) { (success) in
            if success {
                print("压缩/转码 成功")
            }else{
                print("压缩/转码 失败")
            }
        }
    }

    //MARK: 视频压缩//转换格式
    
    /// 视频压缩//转换格式
    /// - Parameters:
    ///   - inputURL: 视频地址
    ///   - outputURL: 视频压缩后的地址
    ///   - presetName: 视频预设
    ///   - completeHandler: <#completeHandler description#>
    /// - Returns: <#description#>
    func convertVideo(inputURL:URL, outputURL:URL, presetName:String = AVAssetExportPresetMediumQuality, completeHandler:@escaping (Bool)->()) {
        let avAsset = AVURLAsset.init(url: inputURL)
        let avAssetExportSession = AVAssetExportSession.init(asset: avAsset, presetName: presetName)
        avAssetExportSession?.outputURL = outputURL
        avAssetExportSession?.outputFileType = .mp4
        //mp4/mov/m4v/m4a/mobile3GPP/mobile3GPP2/caf/wav/aiff/aifc/amr/mp3/au/ac3/eac3/jpg/dng/heic/avci/heif/tif
        //常见视频格式：mp4/mov/m4v/wav
        avAssetExportSession?.shouldOptimizeForNetworkUse = true
        avAssetExportSession?.exportAsynchronously {
            switch avAssetExportSession?.status {
            
            case .unknown:
                print("AVAssetExportSessionStatusUnknown")
                break
            case .waiting:
                print("AVAssetExportSessionStatusWaiting")
                break

            case .exporting:
                print("AVAssetExportSessionStatusExporting")
                break

            case .completed:
                print("AVAssetExportSessionStatusCompleted")
                self.getVideoSize(videoUrl: outputURL)
                self.getVideoLength(videoUrl: outputURL)
                completeHandler(true)
                break

            case .failed:
                print("AVAssetExportSessionStatusFailed")
                completeHandler(false)
                break

            case .cancelled:
                print("AVAssetExportSessionStatusCancelled")
                completeHandler(false)
                break

            default:
                break
            }
        }
    }
    
    
    //MARK: 获取视频时长（秒数）
    func getVideoLength(videoUrl: URL) {
        let avUrlAsset = AVURLAsset.init(url: videoUrl)
        let cmtime = avUrlAsset.duration
        let second = Int(cmtime.seconds)
        
        print("视频秒数 == \(second)")
    }
    
    //MARK: 获取视频文件大小//文件属性
    func getVideoSize(videoUrl: URL) {
        let path = videoUrl.path
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path) {
            let fileDic = try! fileManager.attributesOfItem(atPath: path)
            print("文件属性")
            print(fileDic)
            let size = fileDic[FileAttributeKey(rawValue: "NSFileSize")] as? Int ?? 0
            print("\(size)B")
            print("\(size/1024)KB")
            let sizeM = String(format: "%.2f", Float(size)/1024/1024)
            print(sizeM + "M")
            
        }else{
            print("文件不存在")
        }
    }
    
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }
}
