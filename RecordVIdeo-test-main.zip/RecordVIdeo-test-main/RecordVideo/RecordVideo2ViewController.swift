//
//  RecordVideo2ViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit
import  AVFoundation
import SnapKit
import Photos

class RecordVideo2ViewController: UIViewController {
    
    // 视频捕获会话
    let captureSession = AVCaptureSession()
    // 视频输出
    let fileOutput = AVCaptureMovieFileOutput()
    
    //是否在录像中
    var isRecording = false
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black
        
        AVCaptureDevice.requestAccess(for: AVMediaType.video) {[weak self] (granted) in
            guard let weakSelf = self else {
                return
            }
            if !granted {
                print("无权限访问相机")
                weakSelf.closePage()
                return
            }
            
            weakSelf.addInputVideo()
            
            AVCaptureDevice.requestAccess(for: AVMediaType.audio) {[weak self] (granted) in
                guard let weakSelf = self else {
                    return
                }
                
                if !granted {
                    print("无权限访问麦克风")
                    weakSelf.closePage()
                    return
                }
                
                weakSelf.addInputAudio()

                weakSelf.setOutput()
                //使用AVCaptureVideoPreviewLayer可以将摄像头的拍摄的实时画面显示在ViewController上
                DispatchQueue.main.async {
                    weakSelf.videoLayer.frame = weakSelf.view.bounds
                    weakSelf.view.layer.addSublayer(weakSelf.videoLayer)
                    weakSelf.captureSession.startRunning()
                    //创建按钮
                    weakSelf.setUI()
                }
            }
        }
    }
    
    //MARK: 添加视频输入设备
    func addInputVideo() {
        self.captureSession.beginConfiguration()
        let videoDevice = AVCaptureDevice.default(for: AVMediaType.video)!
        let videoInput = try? AVCaptureDeviceInput(device: videoDevice)
        
        if self.captureSession.canAddInput(videoInput!) {
            self.captureSession.addInput(videoInput!)
        }
        
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 添加音频输入设备
    func addInputAudio() {
        self.captureSession.beginConfiguration()
        let audioDevice = AVCaptureDevice.default(for: AVMediaType.audio)
        let audioInput = try? AVCaptureDeviceInput(device: audioDevice!)
        if self.captureSession.canAddInput(audioInput!) {
            self.captureSession.addInput(audioInput!);
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置分辨率
    func setPreset() {
        self.captureSession.beginConfiguration()
        if self.captureSession.canSetSessionPreset(AVCaptureSession.Preset.hd1280x720) {
            self.captureSession.sessionPreset = AVCaptureSession.Preset.hd1280x720
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置输出
    func setOutput() {
        self.captureSession.beginConfiguration()
        
        if let captureConnection = self.fileOutput.connection(with: AVMediaType.video) {
            // 防止抖动
            if captureConnection.isVideoStabilizationSupported {
                captureConnection.preferredVideoStabilizationMode = .auto
            }
            // 预览图层和视频方向保存一直
            captureConnection.videoOrientation = (self.videoLayer.connection?.videoOrientation)!
        }
        // 视频时长默认10秒，此设置不受限制
        self.fileOutput.movieFragmentInterval = CMTime.invalid
        if  self.captureSession.canAddOutput(self.fileOutput) {
            self.captureSession.addOutput(self.fileOutput)
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置按钮
    func setUI() {
        
        self.view.addSubview(self.closeButton)
        self.closeButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(20)
            make.width.height.equalTo(44)
        }
        self.view.addSubview(self.starButton)
        self.starButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(50)
            make.bottom.equalToSuperview().offset(-40)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
        
        self.view.addSubview(self.stopButton)
        self.stopButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-50)
            make.bottom.equalToSuperview().offset(-40)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
    }
    
    //MARK: 开始录制
    @objc func starRecordVideo() {
        
        if  !self.isRecording {
            //设置录像的保存地址
            let filePath = self.getNewPath(videoTyle: AVFileType.mp4)
            let fileURL = URL(fileURLWithPath: filePath)
            //启动视频编码输出
            fileOutput.startRecording(to:fileURL, recordingDelegate:  self )
            
            //记录状态：录像中...
            self.isRecording = true
            //开始、结束按钮颜色改变
            self.starButton.backgroundColor = UIColor.lightGray
            self.starButton.isEnabled = false
            
            self.stopButton.backgroundColor = UIColor.blue
            self.stopButton.isEnabled = true
        }
    }
    
    //MARK: 结束录制
    @objc func stopRecordVideo() {
        if self.isRecording {
            //停止视频编码输出
            fileOutput.stopRecording()
            
            //记录状态：录像结束
            self .isRecording =  false
            
            //开始、结束按钮颜色改变
            self.starButton.backgroundColor = UIColor.red
            self.starButton.isEnabled = true
            
            self.stopButton.backgroundColor = UIColor.lightGray
            self.stopButton.isEnabled = false
        }
    }
    
    //MARK:关闭页面
    @objc func closePage() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    
    /// 开始按钮
    lazy var starButton: UIButton = {
        let starButton = UIButton()
        starButton.setTitle("开始", for: .normal)
        starButton.backgroundColor = UIColor.red
        starButton.addTarget(self, action: #selector(starRecordVideo), for: .touchUpInside)
        return starButton
    }()
    
    /// 结束按钮
    lazy var stopButton: UIButton = {
        let stopButton = UIButton()
        stopButton.setTitle("结束", for: .normal)
        stopButton.backgroundColor = UIColor.lightGray
        stopButton.addTarget(self, action: #selector(stopRecordVideo), for: .touchUpInside)
        stopButton.isEnabled = false
        return stopButton
    }()
    
    /// 关闭按钮
    lazy var closeButton: UIButton = {
        let closeButton = UIButton()
        closeButton.setImage(UIImage(named: "camera_close"), for: .normal)
        closeButton.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        closeButton.addTarget(self, action: #selector(closePage), for: .touchUpInside)
        return closeButton
    }()
    
    /// 摄像头采集画面
    lazy var videoLayer: AVCaptureVideoPreviewLayer = {
        let videoLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
        videoLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        videoLayer.masksToBounds = true
        return videoLayer
    }()
}

//MARK: AVCaptureFileOutputRecordingDelegate
extension RecordVideo2ViewController:AVCaptureFileOutputRecordingDelegate
{
    // 开始录制
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        
    }
    // 结束录制
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        // 获取视频文件大小
        self.getVideoSize(videoUrl: outputFileURL)
        // 获取视频文件时长
        self.getVideoLength(videoUrl: outputFileURL)
        // 保存相册一份，便于测试
        self.saveVideoToAlbum(videoUrl: outputFileURL)
        // 获取指定时间的帧
        self.getImage(videoUrl: outputFileURL, cmtime: CMTimeMake(value: 1, timescale: 1), width: 300)
        
        // 压缩视频
        let newPath = self.getNewPath(videoTyle: AVFileType.mov)
        print(newPath)
        self.convertVideo(inputURL: outputFileURL, outputURL: URL(fileURLWithPath: newPath), presetName: AVAssetExportPresetMediumQuality) { (success) in
            if success {
                print("压缩成功")
            }else{
                print("压缩失败")
            }
        }
    }
}


extension RecordVideo2ViewController
{
    //MARK: 保存图片到相册
    func saveImage(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(self.saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc private func saveImage(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: AnyObject) {
        var info = ""
        if error != nil{
            info = "保存图片失败"
        }else{
            info = "保存图片成功"
        }
        print(info)
    }
    
    //MARK:保存视频到相册
    func saveVideoToAlbum(videoUrl: URL) {
        var info = ""
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: videoUrl)
        }) { (success, error) in
            if success {
                info = "保存成功"
            } else {
                info = "保存失败，err = \(error.debugDescription)"
            }
            
            DispatchQueue.main.async {
                let alertVC = UIAlertController(title: info, message: nil, preferredStyle: .alert)
                alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertVC, animated: true, completion: nil)
            }
        }
    }
    
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }
    
    //MARK: 根据路径删除沙盒中某个文件
    func deleteFile(path:String) -> Bool {
        if FileManager.default.fileExists(atPath: path) {
            do {
                try FileManager.default.removeItem(atPath: path)
                return true
            } catch  {
                return false
            }
        }
        return false
    }
    
    //MARK: 获取视频时长（秒数）
    func getVideoLength(videoUrl: URL) {
        let avUrlAsset = AVURLAsset.init(url: videoUrl)
        let cmtime = avUrlAsset.duration
        let second = Int(cmtime.seconds)
        
        print("视频秒数 == \(second)")
    }
    
    //MARK: 获取视频文件大小//文件属性
    func getVideoSize(videoUrl: URL) {
        let path = videoUrl.path
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path) {
            let fileDic = try! fileManager.attributesOfItem(atPath: path)
            print("文件属性")
            print(fileDic)
            let size = fileDic[FileAttributeKey(rawValue: "NSFileSize")] as? Int ?? 0
            print("\(size)B")
            print("\(size/1024)KB")
            let sizeM = String(format: "%.2f", Float(size)/1024/1024)
            print(sizeM + "M")
            
        }else{
            print("文件不存在")
        }
    }
    
//    __C.NSFileAttributeKey(_rawValue: NSFileOwnerAccountName): mobile,
//    __C.NSFileAttributeKey(_rawValue: NSFileOwnerAccountID): 501,
//    __C.NSFileAttributeKey(_rawValue: NSFileSystemFileNumber): 24856920,
//    __C.NSFileAttributeKey(_rawValue: NSFileCreationDate): 2021-04-23 03:16:30 +0000,
//    __C.NSFileAttributeKey(_rawValue: NSFileGroupOwnerAccountName): mobile,
//    __C.NSFileAttributeKey(_rawValue: NSFileType): NSFileTypeRegular,
//    __C.NSFileAttributeKey(_rawValue: NSFileProtectionKey): NSFileProtectionCompleteUntilFirstUserAuthentication,
//    __C.NSFileAttributeKey(_rawValue: NSFileSize): 7153635,
//    __C.NSFileAttributeKey(_rawValue: NSFileExtensionHidden): 0,
//    __C.NSFileAttributeKey(_rawValue: NSFileReferenceCount): 1,
//    __C.NSFileAttributeKey(_rawValue: NSFilePosixPermissions): 420,
//    __C.NSFileAttributeKey(_rawValue: NSFileGroupOwnerAccountID): 501,
//    __C.NSFileAttributeKey(_rawValue: NSFileSystemNumber): 16777218,
//    __C.NSFileAttributeKey(_rawValue: NSFileModificationDate): 2021-04-23 03:16:38 +0000
    
//    NSFileOwnerAccountName 这个键的值需要设置为一个NSString对象，表示这个目录的所有者的名字。
//    NSFileOwnerAccountID 这个键的值需要设置为一个表示unsigned int的NSNumber对象，表示目录的所有者ID。
//    NSFileSystemFileNumber
//    NSFileCreationDate 这个键的值需要设置为一个NSDate对象，表示目录的创建时间
//    NSFileGroupOwnerAccountName 这个键的值需要设置为一个NSString对象，表示这个目录的用户组的名字。
//    NSFileType
//    NSFileProtectionKey
//    NSFileSize 文件大小 单位为B
//    NSFileExtensionHidden
//    NSFileReferenceCount 这个键的值需要设置为一个表示unsigned long的NSNumber对象，表示目录的引用计数，即这个目录的硬链接数。
//    NSFilePosixPermissions 这个键的值需要设置为一个表示short int的NSNumber对象，表示目录的访问权限。
//    NSFileGroupOwnerAccountID 这个键的值需要设置为一个表示unsigned int的NSNumber对象，表示目录的组ID。
//    NSFileSystemNumber
//    NSFileModificationDate 这个键的值需要设置一个NSDate对象，表示目录的修改时间。
    
    //MARK: 视频压缩//转换格式
    
    /// 视频压缩//转换格式
    /// - Parameters:
    ///   - inputURL: 视频地址
    ///   - outputURL: 视频压缩后的地址
    ///   - presetName: 视频预设
    ///   - completeHandler: <#completeHandler description#>
    /// - Returns: <#description#>
    func convertVideo(inputURL:URL, outputURL:URL, presetName:String = AVAssetExportPresetMediumQuality, completeHandler:@escaping (Bool)->()) {
        let avAsset = AVURLAsset.init(url: inputURL)
        let avAssetExportSession = AVAssetExportSession.init(asset: avAsset, presetName: presetName)
        avAssetExportSession?.outputURL = outputURL
        avAssetExportSession?.outputFileType = .mp4
        //mp4/mov/m4v/m4a/mobile3GPP/mobile3GPP2/caf/wav/aiff/aifc/amr/mp3/au/ac3/eac3/jpg/dng/heic/avci/heif/tif
        //常见视频格式：mp4/mov/m4v/wav
        avAssetExportSession?.shouldOptimizeForNetworkUse = true
        avAssetExportSession?.exportAsynchronously {
            switch avAssetExportSession?.status {
            
            case .unknown:
                print("AVAssetExportSessionStatusUnknown")
                break
            case .waiting:
                print("AVAssetExportSessionStatusWaiting")
                break

            case .exporting:
                print("AVAssetExportSessionStatusExporting")
                break

            case .completed:
                print("AVAssetExportSessionStatusCompleted")
                self.getVideoSize(videoUrl: outputURL)
                self.getVideoLength(videoUrl: outputURL)
                completeHandler(true)
                break

            case .failed:
                print("AVAssetExportSessionStatusFailed")
                completeHandler(false)
                break

            case .cancelled:
                print("AVAssetExportSessionStatusCancelled")
                completeHandler(false)
                break

            default:
                break
            }
        }
    }
 
    
    //MARK: 获取指定时间帧图片
    
    /// 获取指定时间帧图片
    /// - Parameters:
    ///   - videoUrl: 视频地址
    ///   - cmtime: 指定的时间
    ///   - width: 宽度 根据视频的宽高比来计算图片的高度
    func getImage(videoUrl: URL, cmtime:CMTime = CMTime.zero, width:CGFloat) {
        // 获取指定时间的帧图片
        DispatchQueue.global().async {
            //建立新的AVAsset & AVAssetImageGenerator
            let asset = AVAsset.init(url: videoUrl)
            let imageGenerator = AVAssetImageGenerator.init(asset: asset)
            //设置maximumSize 宽为100，高为0 根据视频的宽高比来计算图片的高度 控制图片清晰度
            imageGenerator.maximumSize = CGSize(width: width, height: 0)
            //捕捉视频缩略图会考虑视频的变化（如视频的方向变化），如果不设置，缩略图的方向可能出错
            imageGenerator.appliesPreferredTrackTransform = true
            //获取CGImageRef图片 注意需要自己管理它的创建和释放
            // CMTimeMake第一个参数是时间，第二个参数是 每秒的分数 第一个/第二个 才是秒
            let imageRef = try! imageGenerator.copyCGImage(at:cmtime, actualTime: nil)
            //将图片转化为UIImage
            let image = UIImage.init(cgImage: imageRef)
            DispatchQueue.main.async {
                //保存到相册
                self.saveImage(image: image)
            }
        }
    }
}
