//
//  RecordVideo3ViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/25.
//

import UIKit
import AVFoundation
import CoreMotion

class RecordVideo3ViewController: UIViewController {
    
    /// 视频捕获会话
    let captureSession = AVCaptureSession()
    /// 是否在录像中
    var isRecording = false
    /// 是否可以写入
    var canWrite = false
    /// 视频路径
    var videoPath:String = ""
    
    var assetWriter:AVAssetWriter?
    var assetWriterVideoInput:AVAssetWriterInput?
    var assetWriterAudioInput:AVAssetWriterInput?
    
    /// 陀螺仪
    var motionManager: CMMotionManager?
    /// 屏幕旋转方向
    var shootingOrientation = UIDeviceOrientation.portrait
    
    var sessionQueue:DispatchQueue?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.black
        self.sessionQueue = DispatchQueue(label: "com.SDJG.LCAVCaptureSession")

        AVCaptureDevice.requestAccess(for: AVMediaType.video) {[weak self] (granted) in
            guard let weakSelf = self else {
                return
            }
            if !granted {
                print("无权限访问相机")
                weakSelf.closePage()
                return
            }
            
            weakSelf.addInputVideo()
            
            AVCaptureDevice.requestAccess(for: AVMediaType.audio) {[weak self] (granted) in
                guard let weakSelf = self else {
                    return
                }
                
                if !granted {
                    print("无权限访问麦克风")
                    weakSelf.closePage()
                    return
                }
                
                weakSelf.addInputAudio()

                weakSelf.addOutputVideoAndAudio()
                
                //使用AVCaptureVideoPreviewLayer可以将摄像头的拍摄的实时画面显示在ViewController上
                DispatchQueue.main.async {
                    weakSelf.videoLayer.frame = weakSelf.view.bounds
                    weakSelf.view.layer.addSublayer(weakSelf.videoLayer)
                    
                    weakSelf.captureSession.startRunning()
                    //创建按钮
                    weakSelf.setUI()
                    //监听屏幕方向
                    weakSelf.startUpdateAccelerometer()
                }
            }
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        self.stopUpdateAccelerometer()
    }
    
    //MARK: 添加视频输入设备
    func addInputVideo() {
        self.captureSession.beginConfiguration()
        
//        let videoDevice = AVCaptureDevice.default(AVCaptureDevice.DeviceType.builtInWideAngleCamera, for: AVMediaType.video, position: AVCaptureDevice.Position.back)
        
        let videoDevice = AVCaptureDevice.default(for: AVMediaType.video)!
        let videoInput = try? AVCaptureDeviceInput(device: videoDevice)
        
        if self.captureSession.canAddInput(videoInput!) {
            self.captureSession.addInput(videoInput!)
        }
        
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 添加音频输入设备
    func addInputAudio() {
        self.captureSession.beginConfiguration()
        
        let audioDevice = AVCaptureDevice.default(for: AVMediaType.audio)
        let audioInput = try? AVCaptureDeviceInput(device: audioDevice!)
        
        if self.captureSession.canAddInput(audioInput!) {
            self.captureSession.addInput(audioInput!);
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 添加视频输出、音频输出
    func addOutputVideoAndAudio() {
        self.captureSession.beginConfiguration()
        
        self.videoDataOutput.setSampleBufferDelegate(self, queue: self.sessionQueue!)
        if self.captureSession.canAddOutput(self.videoDataOutput) {
            self.captureSession.addOutput(self.videoDataOutput)
        }
        
        self.audioDataOutput.setSampleBufferDelegate(self, queue: self.sessionQueue)
        if self.captureSession.canAddOutput(self.audioDataOutput) {
            self.captureSession.addOutput(self.audioDataOutput)
        }
        
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置分辨率
    func setPreset() {
        self.captureSession.beginConfiguration()
        if self.captureSession.canSetSessionPreset(AVCaptureSession.Preset.hd1280x720) {
            self.captureSession.sessionPreset = AVCaptureSession.Preset.hd1280x720
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置按钮
    func setUI() {
        
        self.view.addSubview(self.closeButton)
        self.closeButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(20)
            make.width.height.equalTo(44)
        }
        self.view.addSubview(self.starButton)
        self.starButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(50)
            make.bottom.equalToSuperview().offset(-40)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
        
        self.view.addSubview(self.stopButton)
        self.stopButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-50)
            make.bottom.equalToSuperview().offset(-40)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
    }
    
    //MARK: 开始监听屏幕方向
    func startUpdateAccelerometer() {
        self.motionManager = CMMotionManager()
        if ((self.motionManager?.isAccelerometerAvailable) != nil) {
            self.motionManager?.accelerometerUpdateInterval = 1.0
            self.motionManager?.startAccelerometerUpdates(to: OperationQueue.current!) { (accelerometerData, error) in
                let x = accelerometerData?.acceleration.x ?? 0
                let y = accelerometerData?.acceleration.y ?? 0
                if (fabs(y) + 0.1) >= fabs(y) {
                    if y >= 0.1 {
                        // Down
                        self.shootingOrientation = UIDeviceOrientation.portraitUpsideDown
                    } else {
                        // Portrait
                        self.shootingOrientation = UIDeviceOrientation.portrait;
                    }
                }else {
                    if x >= 0.1{
                        // Right
                        self.shootingOrientation = UIDeviceOrientation.landscapeRight;
                    } else if x <= 0.1 {
                        // Left
                        self.shootingOrientation = UIDeviceOrientation.landscapeLeft;
                    } else {
                        // Portrait
                        self.shootingOrientation = UIDeviceOrientation.portrait;
                    }
                }
                
            }
        }
    }
    
    //MARK: 结束监听屏幕方向
    func stopUpdateAccelerometer() {
        if ((self.motionManager?.isAccelerometerActive) != nil) {
            self.motionManager?.stopAccelerometerUpdates()
            self.motionManager = nil
        }
    }
    
    //MARK: 设置AssetWrite
    func setAssetWriter(videoPath: String) {
        //设置录像的保存地址
        let fileURL = URL(fileURLWithPath: videoPath)
        
        if let assetWriter = try? AVAssetWriter.init(url: fileURL, fileType: AVFileType.mp4) {
            self.assetWriter = assetWriter
              
            var width = UIScreen.main.bounds.size.height
            
            var height = UIScreen.main.bounds.size.width
            //写入视频大小
            let numPixels = width*height
            //每像素比特
            let bitsPerPixel:CGFloat = 12.0;
            let bitsPerSecond = numPixels * bitsPerPixel;
            if (false) // 是否是刘海屏
            {
                width = UIScreen.main.bounds.size.height - 146;
                height = UIScreen.main.bounds.size.width;
            }
                
            let compressionProperties = [
                // 视频尺寸*比率，10.1相当于AVCaptureSessionPresetHigh，数值越大，显示越精细
                AVVideoAverageBitRateKey : bitsPerSecond,
                // 设置输出帧率
                AVVideoExpectedSourceFrameRateKey : 15,
                // 关键帧最大间隔，1为每个都是关键帧，数值越大压缩率越高
                AVVideoMaxKeyFrameIntervalKey : 15,
                // 画面质量
                AVVideoProfileLevelKey : AVVideoProfileLevelH264BaselineAutoLevel
            ] as [String : Any]
            
            let videoCompressionSettings = [
                AVVideoCodecKey : AVVideoCodecH264,
                AVVideoWidthKey : width * 2,
                AVVideoHeightKey : height * 2,
//                AVVideoScalingModeKey : AVVideoScalingModeResizeAspectFill,
                AVVideoCompressionPropertiesKey : compressionProperties
            ] as [String : Any]
            
            self.assetWriterVideoInput = AVAssetWriterInput.init(mediaType: AVMediaType.video, outputSettings: videoCompressionSettings)
            //expectsMediaDataInRealTime 必须设为yes，需要从capture session 实时获取数据
            self.assetWriterVideoInput?.expectsMediaDataInRealTime = true
            // 拍摄出来的是横屏，下面代码强制竖屏，和添加水印有冲突
//            if self.shootingOrientation == UIDeviceOrientation.landscapeRight {
//                self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
//            } else if self.shootingOrientation == UIDeviceOrientation.landscapeLeft {
//                self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: 0)
//            }else if (self.shootingOrientation == UIDeviceOrientation.portraitUpsideDown) {
//                self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi + (Double.pi / 2.0)))
//            } else {
//                self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi / 2.0))
//            }
            
            // 音频设置
            let audioCompressionSettings = [
                // 每个声道的比特率
                AVEncoderBitRatePerChannelKey : 28000,
                // 设置录音格式
                AVFormatIDKey : kAudioFormatMPEG4AAC,
                // 设置通道,单声道，双声道  mp3 必须双声道
                AVNumberOfChannelsKey : 1,
                // 设置录音采样率，8000是电话采样率，对于一般录音已经够了
                AVSampleRateKey : 22050,
                // 每个采样点位数,分为8、16、24、32
//                AVLinearPCMBitDepthKey: 16,
                // 质量
//                AVEncoderAudioQualityKey: AVAudioQuality.medium
            ] as [String : Any]
            
            self.assetWriterAudioInput = AVAssetWriterInput.init(mediaType: AVMediaType.audio, outputSettings: audioCompressionSettings)
            self.assetWriterAudioInput?.expectsMediaDataInRealTime = true
            if self.assetWriter!.canAdd(self.assetWriterVideoInput!) {
                self.assetWriter?.add(self.assetWriterVideoInput!)
            }
            
            if self.assetWriter!.canAdd(self.assetWriterAudioInput!) {
                self.assetWriter?.add(self.assetWriterAudioInput!)
            }
            
            self.canWrite = false
            
        } else {
            print("加载AVAssetWriter失败")
        }
    }
    
    //MARK: 开始录制
    @objc func starRecordVideo() {
        
        if  !self.isRecording {
            print("开始录制")
            //设置录像的保存地址
            self.videoPath = self.getNewPath(videoTyle: AVFileType.mp4)
            print(self.videoPath)
            setAssetWriter(videoPath: self.videoPath)
            
            //记录状态：录像中...
            self.isRecording = true
            //开始、结束按钮颜色改变
            self.starButton.backgroundColor = UIColor.lightGray
            self.starButton.isEnabled = false
            
            self.stopButton.backgroundColor = UIColor.blue
            self.stopButton.isEnabled = true
        }
        
    }
    
    //MARK: 结束录制
    @objc func stopRecordVideo() {
        if self.isRecording {
            print("结束录制")
            //停止视频编码输出
            if self.assetWriter != nil && self.assetWriter?.status == AVAssetWriter.Status.writing {
                self.assetWriter?.finishWriting { [weak self] in
                    guard let weakSelf = self else {
                        return
                    }
                    weakSelf.canWrite = false
                    weakSelf.assetWriter = nil
                    weakSelf.assetWriterAudioInput = nil
                    weakSelf.assetWriterVideoInput = nil
                }
            }
            
            //记录状态：录像结束
            self .isRecording =  false
            
            //开始、结束按钮颜色改变
            self.starButton.backgroundColor = UIColor.red
            self.starButton.isEnabled = true
            
            self.stopButton.backgroundColor = UIColor.lightGray
            self.stopButton.isEnabled = false
        }
    }
    
    //MARK:关闭页面
    @objc func closePage() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    
    /// 开始按钮
    lazy var starButton: UIButton = {
        let starButton = UIButton()
        starButton.setTitle("开始", for: .normal)
        starButton.backgroundColor = UIColor.red
        starButton.addTarget(self, action: #selector(starRecordVideo), for: .touchUpInside)
        return starButton
    }()
    
    /// 结束按钮
    lazy var stopButton: UIButton = {
        let stopButton = UIButton()
        stopButton.setTitle("结束", for: .normal)
        stopButton.backgroundColor = UIColor.lightGray
        stopButton.addTarget(self, action: #selector(stopRecordVideo), for: .touchUpInside)
        stopButton.isEnabled = false
        return stopButton
    }()
    
    /// 关闭按钮
    lazy var closeButton: UIButton = {
        let closeButton = UIButton()
        closeButton.setImage(UIImage(named: "camera_close"), for: .normal)
        closeButton.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        closeButton.addTarget(self, action: #selector(closePage), for: .touchUpInside)
        return closeButton
    }()
    
    /// 摄像头采集画面
    lazy var videoLayer: AVCaptureVideoPreviewLayer = {
        let videoLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
        videoLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        videoLayer.masksToBounds = true
        return videoLayer
    }()
    
    /// 视频输出
    lazy var videoDataOutput: AVCaptureVideoDataOutput = {
        let videoDataOutput = AVCaptureVideoDataOutput()
        videoDataOutput.videoSettings = [((kCVPixelBufferPixelFormatTypeKey as NSString) as String):NSNumber(value:kCVPixelFormatType_32BGRA)]
        return videoDataOutput
    }()
   
    
    /// 音频输出
    lazy var audioDataOutput: AVCaptureAudioDataOutput = {
        let audioDataOutput = AVCaptureAudioDataOutput()
        audioDataOutput.setSampleBufferDelegate(self, queue: self.sessionQueue)
        return audioDataOutput
    }()

}


extension RecordVideo3ViewController: AVCaptureVideoDataOutputSampleBufferDelegate,AVCaptureAudioDataOutputSampleBufferDelegate
{
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//        CVImageBufferRef imageBufferRef=CMSampleBufferGetImageBuffer(sampleBuffer);
//        CVPixelBuffer图像格式转换成CMSampleBuffer
//        https://blog.csdn.net/qq26983255/article/details/89479788
        
//        https://www.it1352.com/1956054.html
        // 美颜
//        https://blog.csdn.net/Xoxo_x/article/details/52523466
        
        autoreleasepool {
            if !isRecording {
                return
            }
            if connection == self.videoDataOutput.connection(with: AVMediaType.video) {
                objc_sync_enter(self)
                //以下注释 第三步行不通 行不通，可以参考AVAssetWriterInputPixelBufferAdaptor来做，
//                let currentTime = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
//                // 第一步 CMSampleBuffer转uiimage
//                let image = self.sampleBufferToImage(sampleBuffer: sampleBuffer)
//                // 第二步 图片合成（水印）
//                let newImage = self.imageAddWaterImage(image: image, waterImage: UIImage(named: "good")!)
//                // 第三步 uiimage 转 CMSampleBuffer
//                if let newSampleBuffer = self.imageToCMSampleBuffer(image: newImage) {
//                    self.appendSampleBuffer(sampleBuffer: newSampleBuffer, mediaType: AVMediaType.video, cmtime: currentTime)
//                }
                self.appendSampleBuffer(sampleBuffer: sampleBuffer, mediaType: AVMediaType.video)
                objc_sync_exit(self)
            }
            if connection == self.audioDataOutput.connection(with: AVMediaType.audio) {
                objc_sync_enter(self)
                self.appendSampleBuffer(sampleBuffer: sampleBuffer, mediaType: AVMediaType.audio)
                objc_sync_exit(self)
            }
        }
    }
    
    // CMSampleBuffer -> UIImage
    func sampleBufferToImage(sampleBuffer: CMSampleBuffer) -> UIImage {
        // 获取CMSampleBuffer的核心视频图像缓冲的媒体数据
        let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)! as CVPixelBuffer

        // 锁定像素缓冲区的基址
        CVPixelBufferLockBaseAddress(imageBuffer, CVPixelBufferLockFlags(rawValue: 0))

        // 获取像素缓冲区的每行字节数
        let baseAddress = CVPixelBufferGetBaseAddress(imageBuffer)
        
        // 获取像素缓冲区的每行字节数
        let bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer)
        // 获取像素缓冲的宽度和高度
        let width = CVPixelBufferGetWidth(imageBuffer)
        let height = CVPixelBufferGetHeight(imageBuffer)
        
        // 创建一个设备相关的RGB颜色空间
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        
        // 使用示例缓冲区数据创建位图图形上下文
        let context = CGContext(data: baseAddress, width: width, height: height, bitsPerComponent: 8,
                                bytesPerRow: bytesPerRow, space: colorSpace, bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue)
        // 根据位图图形上下文中的像素数据创建一个Quartz图像
        let quartzImage:CGImage = context!.makeImage()!
        // 解锁像素缓冲区
        CVPixelBufferUnlockBaseAddress(imageBuffer,CVPixelBufferLockFlags(rawValue: 0))
        
        let image = UIImage(cgImage: quartzImage)
        return image
    }
    
    // 图片合成（水印）
    func imageAddWaterImage(image:UIImage, waterImage: UIImage) -> UIImage {
        UIGraphicsBeginImageContext(image.size)
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width,  height: image.size.height))
        
        waterImage.draw(in: CGRect(x: 0, y: 0, width: 100, height: 100), blendMode: .normal, alpha: 1)
        guard let waterMarkedImage = UIGraphicsGetImageFromCurrentImageContext() else {
            return image
        }
        UIGraphicsEndImageContext()
        return waterMarkedImage
    }
    
    
    // UIImage -> CVPixelBuffer
    func imageToCVPixelBuffer(image:UIImage) -> CVPixelBuffer? {
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer : CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(image.size.width),
                                         Int(image.size.height),
                                         kCVPixelFormatType_32ARGB,
                                         attrs,
                                         &pixelBuffer)
        guard (status == kCVReturnSuccess) else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)
        
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: Int(image.size.width),
                                height: Int(image.size.height),
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)
        
        context?.translateBy(x: 0, y: image.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context!)
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        return pixelBuffer
    }
    
    // UIImage -> CMSampleBuffer
    func imageToCMSampleBuffer(image:UIImage) -> CMSampleBuffer? {
        
        let pixelBuffer = self.imageToCVPixelBuffer(image: image)
        var newSampleBuffer: CMSampleBuffer? = nil
        var timimgInfo: CMSampleTimingInfo = CMSampleTimingInfo.invalid
        var videoInfo: CMVideoFormatDescription? = nil
        
        CMVideoFormatDescriptionCreateForImageBuffer(allocator: nil, imageBuffer: pixelBuffer!, formatDescriptionOut: &videoInfo)
        CMSampleBufferCreateForImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: pixelBuffer!, dataReady: true, makeDataReadyCallback: nil, refcon: nil, formatDescription: videoInfo!, sampleTiming: &timimgInfo, sampleBufferOut: &newSampleBuffer)
        return newSampleBuffer
    }
    
    func appendSampleBuffer(sampleBuffer:CMSampleBuffer, mediaType:AVMediaType, cmtime:CMTime) {
        autoreleasepool {
            if (!self.canWrite && mediaType == AVMediaType.video) {
                print("开始写入AVAssetWriter")
                self.assetWriter?.startWriting()
                self.assetWriter?.startSession(atSourceTime: cmtime)
//                self.assetWriter?.startSession(atSourceTime: CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
                self.canWrite = true
            }
            
            //写入视频数据
            if mediaType == AVMediaType.video {
                if self.assetWriterVideoInput!.isReadyForMoreMediaData {
                    let success = self.assetWriterVideoInput!.append(sampleBuffer)
                    if !success {
                        //停止录像
                        objc_sync_enter(self)
                        self.stopRecordVideo()
                        objc_sync_exit(self)
                    }
                }
            }
            
            //写入音频数据
            if mediaType == AVMediaType.audio {
                if self.assetWriterAudioInput!.isReadyForMoreMediaData {
                    let success = self.assetWriterAudioInput!.append(sampleBuffer)
                    if !success {
                        //停止录像
                        objc_sync_enter(self)
                        self.stopRecordVideo()
                        objc_sync_exit(self)
                    }
                }
            }
        }
    }
    
    
    
    
    func appendSampleBuffer(sampleBuffer:CMSampleBuffer, mediaType:AVMediaType) {
        autoreleasepool {
            if (!self.canWrite && mediaType == AVMediaType.video) {
                print("开始写入AVAssetWriter")
                self.assetWriter?.startWriting()
                self.assetWriter?.startSession(atSourceTime: CMTime.zero)
//                self.assetWriter?.startSession(atSourceTime: CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
                self.canWrite = true
            }
            
            //写入视频数据
            if mediaType == AVMediaType.video {
                if self.assetWriterVideoInput!.isReadyForMoreMediaData {
                    let success = self.assetWriterVideoInput!.append(sampleBuffer)
                    if !success {
                        //停止录像
                        objc_sync_enter(self)
                        self.stopRecordVideo()
                        objc_sync_exit(self)
                    }
                }
            }
            
            //写入视频数据
            if mediaType == AVMediaType.audio {
                if self.assetWriterAudioInput!.isReadyForMoreMediaData {
                    let success = self.assetWriterAudioInput!.append(sampleBuffer)
                    if !success {
                        //停止录像
                        objc_sync_enter(self)
                        self.stopRecordVideo()
                        objc_sync_exit(self)
                    }
                }
            }
        }
    }
}


extension RecordVideo3ViewController
{
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }
}
