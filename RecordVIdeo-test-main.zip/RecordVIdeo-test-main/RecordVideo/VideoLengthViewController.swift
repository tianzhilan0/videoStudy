//
//  VideoLengthViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit
import AVFoundation

/// 获取视频时长（秒数）
class VideoLengthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "获取视频秒数", style: .done, target: self, action: #selector(getVideoLength))
    }
    
    
    //MARK: 获取视频时长（秒数）
    @objc func getVideoLength() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619172935.mp4"
        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        
        
        let avUrlAsset = AVURLAsset.init(url: URL(fileURLWithPath: videoPath))
        let cmtime = avUrlAsset.duration
        let second = Int(cmtime.seconds)
        
        print("视频秒数 == \(second)")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
