//
//  VideoOneImageViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit
import AVFoundation

/// 获取指定时间帧图片
class VideoOneImageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "获取指定时间帧图片", style: .done, target: self, action: #selector(getImage))
    }
    

    //MARK: 获取指定时间帧图片
    
    /// 获取指定时间帧图片
    /// - Parameters:
    ///   - videoUrl: 视频地址
    ///   - cmtime: 指定的时间
    ///   - width: 宽度 根据视频的宽高比来计算图片的高度
    @objc func getImage() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619172935.mp4"
        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        
        let cmtime = CMTimeMake(value: 1, timescale: 10)
        let width = 300
        
        // 获取指定时间的帧图片
        DispatchQueue.global().async {
            //建立新的AVAsset & AVAssetImageGenerator
            let asset = AVAsset.init(url: URL(fileURLWithPath: videoPath))
            let imageGenerator = AVAssetImageGenerator.init(asset: asset)
            //设置maximumSize 宽为100，高为0 根据视频的宽高比来计算图片的高度 控制图片清晰度
            imageGenerator.maximumSize = CGSize(width: width, height: 0)
            //捕捉视频缩略图会考虑视频的变化（如视频的方向变化），如果不设置，缩略图的方向可能出错
            imageGenerator.appliesPreferredTrackTransform = true
            //获取CGImageRef图片 注意需要自己管理它的创建和释放
            // CMTimeMake第一个参数是时间，第二个参数是 每秒的分数 第一个/第二个 才是秒
            let imageRef = try! imageGenerator.copyCGImage(at:cmtime, actualTime: nil)
            //将图片转化为UIImage
            let image = UIImage.init(cgImage: imageRef)
            DispatchQueue.main.async {
                //保存到相册
                self.saveImage(image: image)
            }
        }
    }
    
    //MARK: 保存图片到相册
    func saveImage(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(self.saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc private func saveImage(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: AnyObject) {
        var info = ""
        if error != nil{
            info = "保存图片失败"
        }else{
            info = "保存图片成功"
        }
        print(info)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
