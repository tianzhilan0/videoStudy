//
//  ViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/22.
//

import UIKit

class ViewController: UIViewController {
    
    let items = [
        [
            "title":"视频录制1",
            "detail":"UIImagePickerController",
        ],[
            "title":"视频录制2",
            "detail":"AVCaptureSession + AVCaptureMovieFileOutput",
        ],[
            "title":"视频录制3",
            "detail":"AVCaptureSession + AVAssetWriter",
        ],[
            "title":"视频录制4",
            "detail":"AVCaptureSession + AVAssetWriter + AVAssetWriterInputPixelBufferAdaptor",
        ],[
            "title":"获取视频时长（秒数）",
            "detail":""
        ],[
            "title":"获取视频文件大小",
            "detail":""
        ],[
            "title":"获取指定时间帧图片",
            "detail":""
        ],[
            "title":"视频压缩/转码",
            "detail":"",
        ],[
            "title":"多视频合成",
            "detail":"",
        ],[
            "title":"视频添加水印",
            "detail":""
        ]
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.view.addSubview(self.tableView)
        
        self.tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }

    lazy var tableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style:.plain)
        tableView.backgroundColor = UIColor.white
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
}

extension ViewController: UITableViewDelegate, UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell")
        if cell == nil {
            cell = UITableViewCell.init(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: "UITableViewCell")
        }
        cell?.textLabel?.textColor  = .black
        cell?.textLabel?.text = items[indexPath.row]["title"]
        cell?.detailTextLabel?.text = items[indexPath.row]["detail"]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //AVCaptureSession + AVCaptureMovieFileOutput
        if items[indexPath.row]["title"] == "视频录制1" {
            self.navigationController?.pushViewController(RecordVideoViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "视频录制2" {
            self.navigationController?.pushViewController(RecordVideo2ViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "视频录制3" {
            self.navigationController?.pushViewController(RecordVideo3ViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "视频录制4" {
            self.navigationController?.pushViewController(RecordVideo4ViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "获取视频时长（秒数）" {
            self.navigationController?.pushViewController(VideoLengthViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "获取视频文件大小" {
            self.navigationController?.pushViewController(VideoSizeViewController(), animated: true)
        }
        if items[indexPath.row]["title"] == "获取指定时间帧图片" {
            self.navigationController?.pushViewController(VideoOneImageViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "视频压缩/转码" {
            self.navigationController?.pushViewController(VideoCompressViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "多视频合成" {
            self.navigationController?.pushViewController(VideoMergeViewController(), animated: true)
        }
        
        if items[indexPath.row]["title"] == "视频添加水印" {
            self.navigationController?.pushViewController(VideoAddMarkViewController(), animated: true)
        }
        
    }
}

