//
//  RecordVideo4ViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/27.
//

import UIKit
import AVFoundation
import CoreMotion

class RecordVideo4ViewController: UIViewController {

    /// 视频捕获会话
    let captureSession = AVCaptureSession()
    /// 是否在录像中
    var isRecording = false

    /// 视频路径
    var videoPath:String = ""
    
    var assetWriter:AVAssetWriter?
    var assetWriterVideoInput:AVAssetWriterInput?
    var assetWriterAudioInput:AVAssetWriterInput?
    
    /// 陀螺仪
    var motionManager: CMMotionManager?
    /// 屏幕旋转方向
    var shootingOrientation = UIDeviceOrientation.portrait
    
    var sessionQueue:DispatchQueue?
    
    var adaptor:AVAssetWriterInputPixelBufferAdaptor?
    var frameCount:Int64 = 0
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.black
        self.sessionQueue = DispatchQueue(label: "com.SDJG.LCAVCaptureSession")
        
        AVCaptureDevice.requestAccess(for: AVMediaType.video) {[weak self] (granted) in
            guard let weakSelf = self else {
                return
            }
            if !granted {
                print("无权限访问相机")
                weakSelf.closePage()
                return
            }
                        
            AVCaptureDevice.requestAccess(for: AVMediaType.audio) {[weak self] (granted) in
                guard let weakSelf = self else {
                    return
                }
                
                if !granted {
                    print("无权限访问麦克风")
                    weakSelf.closePage()
                    return
                }
                
                weakSelf.addInputVideoAndAudio()

                weakSelf.addOutputVideoAndAudio()
                
                //使用AVCaptureVideoPreviewLayer可以将摄像头的拍摄的实时画面显示在ViewController上
                DispatchQueue.main.async {
                    weakSelf.videoLayer.frame = weakSelf.view.bounds
                    weakSelf.view.layer.addSublayer(weakSelf.videoLayer)
                    
                    weakSelf.captureSession.startRunning()
                    //创建按钮
                    weakSelf.setUI()
                    //监听屏幕方向
                    weakSelf.startUpdateAccelerometer()
                }
            }
        }

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        self.stopUpdateAccelerometer()
    }
    
    
    //MARK: 添加频输、音频输入设备
    func addInputVideoAndAudio() {
        self.captureSession.beginConfiguration()
        
        let videoDevice = AVCaptureDevice.default(for: AVMediaType.video)!
        let videoInput = try? AVCaptureDeviceInput(device: videoDevice)
        
        if self.captureSession.canAddInput(videoInput!) {
            self.captureSession.addInput(videoInput!)
        }
        
        let audioDevice = AVCaptureDevice.default(for: AVMediaType.audio)
        let audioInput = try? AVCaptureDeviceInput(device: audioDevice!)
        
        if self.captureSession.canAddInput(audioInput!) {
            self.captureSession.addInput(audioInput!);
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 添加视频输出、音频输出
    func addOutputVideoAndAudio() {
        self.captureSession.beginConfiguration()
        
        if self.captureSession.canAddOutput(self.videoDataOutput) {
            self.captureSession.addOutput(self.videoDataOutput)
        }
        
        if self.captureSession.canAddOutput(self.audioDataOutput) {
            self.captureSession.addOutput(self.audioDataOutput)
        }
        
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置分辨率
    func setPreset() {
        self.captureSession.beginConfiguration()
        if self.captureSession.canSetSessionPreset(AVCaptureSession.Preset.hd1280x720) {
            self.captureSession.sessionPreset = AVCaptureSession.Preset.hd1280x720
        }
        self.captureSession.commitConfiguration()
    }
    
    //MARK: 设置按钮
    func setUI() {
        
        self.view.addSubview(self.closeButton)
        self.closeButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(20)
            make.width.height.equalTo(44)
        }
        self.view.addSubview(self.starButton)
        self.starButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(50)
            make.bottom.equalToSuperview().offset(-40)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
        
        self.view.addSubview(self.stopButton)
        self.stopButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-50)
            make.bottom.equalToSuperview().offset(-40)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
    }
    
    //MARK: 开始监听屏幕方向
    func startUpdateAccelerometer() {
        self.motionManager = CMMotionManager()
        if ((self.motionManager?.isAccelerometerAvailable) != nil) {
            self.motionManager?.accelerometerUpdateInterval = 1.0
            self.motionManager?.startAccelerometerUpdates(to: OperationQueue.current!) { (accelerometerData, error) in
                let x = accelerometerData?.acceleration.x ?? 0
                let y = accelerometerData?.acceleration.y ?? 0
                if (fabs(y) + 0.1) >= fabs(y) {
                    if y >= 0.1 {
                        // Down
                        self.shootingOrientation = UIDeviceOrientation.portraitUpsideDown
                    } else {
                        // Portrait
                        self.shootingOrientation = UIDeviceOrientation.portrait;
                    }
                }else {
                    if x >= 0.1{
                        // Right
                        self.shootingOrientation = UIDeviceOrientation.landscapeRight;
                    } else if x <= 0.1 {
                        // Left
                        self.shootingOrientation = UIDeviceOrientation.landscapeLeft;
                    } else {
                        // Portrait
                        self.shootingOrientation = UIDeviceOrientation.portrait;
                    }
                }
                
            }
        }
    }
    
    //MARK: 结束监听屏幕方向
    func stopUpdateAccelerometer() {
        if ((self.motionManager?.isAccelerometerActive) != nil) {
            self.motionManager?.stopAccelerometerUpdates()
            self.motionManager = nil
        }
    }
    
    //MARK: 设置AssetWrite
    func setAssetWriter(videoPath: String) {
        //设置录像的保存地址
        let fileURL = URL(fileURLWithPath: videoPath)
        
        do {
            self.assetWriter = try AVAssetWriter.init(url: fileURL, fileType: AVFileType.mp4)
        } catch let error as NSError {
            print("加载AVAssetWriter失败")
            print(error)
            return
        }

        var width = UIScreen.main.bounds.size.height
        
        var height = UIScreen.main.bounds.size.width
        //写入视频大小
        let numPixels = width*height
        //每像素比特
        let bitsPerPixel:CGFloat = 12.0;
        let bitsPerSecond = numPixels * bitsPerPixel;
        if (false) // 是否是刘海屏
        {
            width = UIScreen.main.bounds.size.height - 146;
            height = UIScreen.main.bounds.size.width;
        }
        
        let compressionProperties = [
            // 视频尺寸*比率，10.1相当于AVCaptureSessionPresetHigh，数值越大，显示越精细
            AVVideoAverageBitRateKey : bitsPerSecond,
            // 设置输出帧率
            AVVideoExpectedSourceFrameRateKey : 15,
            // 关键帧最大间隔，1为每个都是关键帧，数值越大压缩率越高
            AVVideoMaxKeyFrameIntervalKey : 15,
            // 画面质量
            AVVideoProfileLevelKey : AVVideoProfileLevelH264BaselineAutoLevel
        ] as [String : Any]
        
        let videoCompressionSettings = [
            AVVideoCodecKey : AVVideoCodecH264,
            AVVideoWidthKey : width * 2,
            AVVideoHeightKey : height * 2,
            //                AVVideoScalingModeKey : AVVideoScalingModeResizeAspectFill,
            AVVideoCompressionPropertiesKey : compressionProperties
        ] as [String : Any]
        
        self.assetWriterVideoInput = AVAssetWriterInput.init(mediaType: AVMediaType.video, outputSettings: videoCompressionSettings)
        let sourcePixelBufferAttributes = [
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32ARGB,
            kCVPixelBufferWidthKey: width*2,
            kCVPixelBufferHeightKey: height*2
        ] as [String : Any]
        
        self.adaptor = AVAssetWriterInputPixelBufferAdaptor.init(assetWriterInput: self.assetWriterVideoInput!, sourcePixelBufferAttributes: sourcePixelBufferAttributes)
        
        //expectsMediaDataInRealTime 必须设为yes，需要从capture session 实时获取数据
        self.assetWriterVideoInput?.expectsMediaDataInRealTime = true
        if self.shootingOrientation == UIDeviceOrientation.landscapeRight {
            self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
        } else if self.shootingOrientation == UIDeviceOrientation.landscapeLeft {
            self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: 0)
        }else if (self.shootingOrientation == UIDeviceOrientation.portraitUpsideDown) {
            self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi + (Double.pi / 2.0)))
        } else {
            self.assetWriterVideoInput?.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi / 2.0))
        }
        
        // 音频设置
        let audioCompressionSettings = [
            // 每个声道的比特率
            AVEncoderBitRatePerChannelKey : 28000,
            // 设置录音格式
            AVFormatIDKey : kAudioFormatMPEG4AAC,
            // 设置通道,单声道，双声道  mp3 必须双声道
            AVNumberOfChannelsKey : 1,
            // 设置录音采样率，8000是电话采样率，对于一般录音已经够了
            AVSampleRateKey : 22050,
        ] as [String : Any]
        
        self.assetWriterAudioInput = AVAssetWriterInput.init(mediaType: AVMediaType.audio, outputSettings: audioCompressionSettings)
        self.assetWriterAudioInput?.expectsMediaDataInRealTime = true
        if self.assetWriter!.canAdd(self.assetWriterVideoInput!) {
            self.assetWriter!.add(self.assetWriterVideoInput!)
        }
        
        if self.assetWriter!.canAdd(self.assetWriterAudioInput!) {
            self.assetWriter!.add(self.assetWriterAudioInput!)
        }
        if self.assetWriter!.status != .writing {
            if self.assetWriter!.startWriting() {
                self.assetWriter!.startSession(atSourceTime: CMTime.zero)
                
                self.adaptor?.assetWriterInput.requestMediaDataWhenReady(on: DispatchQueue(label: "com.SDJG.assetWriterInput"), using: {
                    
                })
            }
        }
    }
    
    //MARK: 开始录制
    @objc func starRecordVideo() {
        
        if  !self.isRecording {
            print("开始录制")
            //设置录像的保存地址
            self.videoPath = self.getNewPath(videoTyle: AVFileType.mp4)
            print(self.videoPath)
            self.frameCount = 0
            setAssetWriter(videoPath: self.videoPath)
            
            //记录状态：录像中...
            self.isRecording = true
            //开始、结束按钮颜色改变
            self.starButton.backgroundColor = UIColor.lightGray
            self.starButton.isEnabled = false
            
            self.stopButton.backgroundColor = UIColor.blue
            self.stopButton.isEnabled = true
        }
        
    }
    
    //MARK: 结束录制
    @objc func stopRecordVideo() {
        if self.isRecording {
            print("结束录制")
            //停止视频编码输出
            if self.assetWriter != nil && self.assetWriter?.status == AVAssetWriter.Status.writing {
                self.adaptor?.assetWriterInput.markAsFinished()
                self.assetWriter?.finishWriting { [weak self] in
                    guard let weakSelf = self else {
                        return
                    }
                    weakSelf.assetWriter = nil
                    weakSelf.assetWriterAudioInput = nil
                    weakSelf.assetWriterVideoInput = nil
                }
            }
            
            //记录状态：录像结束
            self .isRecording =  false
            
            //开始、结束按钮颜色改变
            self.starButton.backgroundColor = UIColor.red
            self.starButton.isEnabled = true
            
            self.stopButton.backgroundColor = UIColor.lightGray
            self.stopButton.isEnabled = false
        }
    }
    
    //MARK:关闭页面
    @objc func closePage() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    
    /// 开始按钮
    lazy var starButton: UIButton = {
        let starButton = UIButton()
        starButton.setTitle("开始", for: .normal)
        starButton.backgroundColor = UIColor.red
        starButton.addTarget(self, action: #selector(starRecordVideo), for: .touchUpInside)
        return starButton
    }()
    
    /// 结束按钮
    lazy var stopButton: UIButton = {
        let stopButton = UIButton()
        stopButton.setTitle("结束", for: .normal)
        stopButton.backgroundColor = UIColor.lightGray
        stopButton.addTarget(self, action: #selector(stopRecordVideo), for: .touchUpInside)
        stopButton.isEnabled = false
        return stopButton
    }()
    
    /// 关闭按钮
    lazy var closeButton: UIButton = {
        let closeButton = UIButton()
        closeButton.setImage(UIImage(named: "camera_close"), for: .normal)
        closeButton.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        closeButton.addTarget(self, action: #selector(closePage), for: .touchUpInside)
        return closeButton
    }()
    
    /// 摄像头采集画面
    lazy var videoLayer: AVCaptureVideoPreviewLayer = {
        let videoLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
        videoLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        videoLayer.masksToBounds = true
        return videoLayer
    }()
    
    /// 视频输出
    lazy var videoDataOutput: AVCaptureVideoDataOutput = {
        let videoDataOutput = AVCaptureVideoDataOutput()
        videoDataOutput.videoSettings = [((kCVPixelBufferPixelFormatTypeKey as NSString) as String):NSNumber(value:kCVPixelFormatType_32BGRA)]
        videoDataOutput.setSampleBufferDelegate(self, queue: sessionQueue)
        return videoDataOutput
    }()
   
    
    /// 音频输出
    lazy var audioDataOutput: AVCaptureAudioDataOutput = {
        let audioDataOutput = AVCaptureAudioDataOutput()
        audioDataOutput.setSampleBufferDelegate(self, queue: sessionQueue)

        return audioDataOutput
    }()

}

extension RecordVideo4ViewController: AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate
{
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        if !self.isRecording {
            return
        }
        
        if connection == self.audioDataOutput.connection(with: AVMediaType.audio) {
            if self.assetWriter!.status == .writing {
                let success = self.assetWriterAudioInput!.append(sampleBuffer)
                if !success {
                    //停止录像
                    self.stopRecordVideo()
                }
            }
            return
        }
        
        let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer!)
        
        if self.adaptor!.assetWriterInput.isReadyForMoreMediaData {
            let fps: Int32 = 15
            let frameDuration = CMTimeMake(value: 1, timescale: fps)
            let lastFrameTime = CMTimeMake(value: self.frameCount, timescale: fps)
            let presentationTime = self.frameCount == 0 ? lastFrameTime : CMTimeAdd(lastFrameTime, frameDuration)
            
            let newImage = self.imageAddWaterImage(image: UIImage(ciImage: ciImage), waterImage: UIImage(named: "good")!)
            let newPixelBuffer = self.imageToCVPixelBuffer(image: newImage)
            if !self.adaptor!.assetWriterInput.isReadyForMoreMediaData {
                return
            }
            if !self.isRecording {
                return
            }
            let whetherPixelBufferAppendedtoAdaptor = self.adaptor!.append(newPixelBuffer!, withPresentationTime: presentationTime)
            
            if whetherPixelBufferAppendedtoAdaptor {
                print("DEBUG:::PixelBuffer appended adaptor successfully")
            } else {
                print("WARN:::PixelBuffer appended adapotr failed")
            }
            
            self.frameCount += 1
            
            print("DEBUG:::The current frame counter = \(self.frameCount)")
        } else {
            print("WARN:::The assetWriterInput is not ready")
        }
    }
    
    // 图片合成（水印）
    func imageAddWaterImage(image:UIImage, waterImage: UIImage) -> UIImage {
        UIGraphicsBeginImageContext(image.size)
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width,  height: image.size.height))
        
        waterImage.draw(in: CGRect(x: 0, y: 0, width: 100, height: 100), blendMode: .normal, alpha: 1)
        guard let waterMarkedImage = UIGraphicsGetImageFromCurrentImageContext() else {
            return image
        }
        UIGraphicsEndImageContext()
        return waterMarkedImage
    }
    
    // UIImage -> CVPixelBuffer
    func imageToCVPixelBuffer(image:UIImage) -> CVPixelBuffer? {
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer : CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(image.size.width),
                                         Int(image.size.height),
                                         kCVPixelFormatType_32ARGB,
                                         attrs,
                                         &pixelBuffer)
        guard (status == kCVReturnSuccess) else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)
        
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: Int(image.size.width),
                                height: Int(image.size.height),
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)
        
        context?.translateBy(x: 0, y: image.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context!)
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        return pixelBuffer
    }
}


extension RecordVideo4ViewController
{
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }
}
