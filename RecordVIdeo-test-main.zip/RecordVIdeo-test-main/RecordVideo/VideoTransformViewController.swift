//
//  VideoTransformViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/25.
//

import UIKit
import AVFoundation


/// 视频旋转
class VideoTransformViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "旋转视频", style: .done, target: self, action: #selector(videoTransform))
    }
    
    @objc func videoTransform() {
        
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619352122.mp4"
        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        let outputPath = self.getNewPath(videoTyle: AVFileType.mp4)
        print(outputPath)
        self.startVideoTransform(inputPath:videoPath, outputPath: outputPath) { (success) in
            if success {
                print("旋转成功")
            }else{
                print("旋转失败")
            }
        }
    }
    
    func startVideoTransform(inputPath:String, outputPath:String, completeHandler:@escaping (Bool)->()) {
                
        let videoAsset = AVURLAsset.init(url: URL(fileURLWithPath: inputPath))
        let videoTracks = videoAsset.tracks(withMediaType: AVMediaType.video)
        if videoTracks.count == 0 {
            return
        }
        let audioTracks = videoAsset.tracks(withMediaType: AVMediaType.video)
        if audioTracks.count == 0 {
            return
        }
        
        let assetVideoTrack = videoTracks.first
        let assetAudioTrack = audioTracks.first
        let transform = (assetVideoTrack?.preferredTransform)!
        
        var degress = 0
        if transform.a == 0,
           transform.b == 1,
           transform.c == -1,
           transform.d == 0
        {
            // Portrait
            degress = 90
        } else if transform.a == 0,
                  transform.b == -1,
                  transform.c == 1,
                  transform.d == 0 {
            // PortraitUpsideDown
            degress = 270
        } else if transform.a == 1,
                  transform.b == 0,
                  transform.c == 0,
                  transform.d == 1 {
            // LandscapeRight
            degress = 0
        } else if transform.a == -1,
                  transform.b == 0,
                  transform.c == 0,
                  transform.d == -1 {
            // LandscapeLeft
            degress = 180
        }
        
//        var instruction = AVMutableVideoCompositionInstruction()
//        var layerInstruction = AVMutableVideoCompositionLayerInstruction.init(assetTrack: assetVideoTrack!)
        
        let mutableComposition = AVMutableComposition()
        let compositionVideoTrack = mutableComposition.addMutableTrack(withMediaType: AVMediaType.video, preferredTrackID: kCMPersistentTrackID_Invalid)
        do {
            try compositionVideoTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration), of: assetVideoTrack!, at: CMTime.zero)
        } catch {
            print("出现错误")
            return
        }
//        try! compositionVideoTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration), of: assetVideoTrack!, at: CMTime.zero)
        
        let compositionAudioTrack = mutableComposition.addMutableTrack(withMediaType: AVMediaType.audio, preferredTrackID: kCMPersistentTrackID_Invalid)
        do {
            try compositionAudioTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration), of: assetAudioTrack!, at: CMTime.zero)
        } catch  {
            print("出现错误")
        }
//        try! compositionAudioTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration), of: assetAudioTrack!, at: CMTime.zero)
        
        var transform1 = CGAffineTransform()
        var transform2 = CGAffineTransform()

        if (degress == 0) {
            transform1 = CGAffineTransform(translationX: 0.0, y: 0.0)
            transform2 = transform1.rotated(by: 0)
        }else if (degress == 90){
            transform1 = CGAffineTransform(translationX: (assetVideoTrack?.naturalSize.height)!, y: 0.0);
            transform2 = transform1.rotated(by:  CGFloat(Double.pi / 2.0))
        }else if (degress == 180){
            transform1 = CGAffineTransform(translationX: (assetVideoTrack?.naturalSize.width)!, y: assetVideoTrack!.naturalSize.height);
            transform2 = transform1.rotated(by: CGFloat(Double.pi))
        }else if (degress == 270){
            transform1 = CGAffineTransform(translationX: 0,y: (assetVideoTrack?.naturalSize.height)!*1.78);
            transform2 = transform1.rotated(by: (assetVideoTrack?.naturalSize.height)!*1.78)
        }
        
        
        let mutableVideoComposition = AVMutableVideoComposition()
        if (degress == 0 || degress == 180) {
            mutableVideoComposition.renderSize = CGSize(width: (assetVideoTrack?.naturalSize.width)!, height:(assetVideoTrack?.naturalSize.height)!)
        }else{
            mutableVideoComposition.renderSize = CGSize(width: (assetVideoTrack?.naturalSize.height)!, height:(assetVideoTrack?.naturalSize.width)!)
        }
        mutableVideoComposition.frameDuration = CMTimeMake(value: 1, timescale: 30)
        
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRangeMake(start: CMTime.zero, duration: mutableComposition.duration)
        
        let layerInstruction = AVMutableVideoCompositionLayerInstruction.init(assetTrack: assetVideoTrack!)
        layerInstruction.setTransform(transform2, at: CMTime.zero)
        instruction.layerInstructions = [layerInstruction]
        mutableVideoComposition.instructions = [instruction]
        
        // 导出合成后的视频
        let outputURL = URL(fileURLWithPath: outputPath)
        let avAssetExportSession = AVAssetExportSession.init(asset: mutableComposition, presetName: AVAssetExportPresetMediumQuality)
        avAssetExportSession?.outputURL = outputURL
        avAssetExportSession?.outputFileType = .mp4
        avAssetExportSession?.shouldOptimizeForNetworkUse = true
        avAssetExportSession?.videoComposition = mutableVideoComposition;

        avAssetExportSession?.exportAsynchronously {
            switch avAssetExportSession?.status {
            
            case .unknown:
                print("AVAssetExportSessionStatusUnknown")
                break
            case .waiting:
                print("AVAssetExportSessionStatusWaiting")
                break

            case .exporting:
                print("AVAssetExportSessionStatusExporting")
                break

            case .completed:
                print("AVAssetExportSessionStatusCompleted")
                self.getVideoSize(videoUrl: outputURL)
                self.getVideoLength(videoUrl: outputURL)
                completeHandler(true)
                break

            case .failed:
                print("AVAssetExportSessionStatusFailed")
                completeHandler(false)
                break

            case .cancelled:
                print("AVAssetExportSessionStatusCancelled")
                completeHandler(false)
                break

            default:
                break
            }
        }
    }
    
    
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }
    
    //MARK: 获取视频时长（秒数）
    func getVideoLength(videoUrl: URL) {
        let avUrlAsset = AVURLAsset.init(url: videoUrl)
        let cmtime = avUrlAsset.duration
        let second = Int(cmtime.seconds)
        
        print("视频秒数 == \(second)")
    }
    
    //MARK: 获取视频文件大小//文件属性
    func getVideoSize(videoUrl: URL) {
        let path = videoUrl.path
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path) {
            let fileDic = try! fileManager.attributesOfItem(atPath: path)
            print("文件属性")
            print(fileDic)
            let size = fileDic[FileAttributeKey(rawValue: "NSFileSize")] as? Int ?? 0
            print("\(size)B")
            print("\(size/1024)KB")
            let sizeM = String(format: "%.2f", Float(size)/1024/1024)
            print(sizeM + "M")
            
        }else{
            print("文件不存在")
        }
    }
}
