//
//  RecordVideoViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/22.
//

import UIKit
import  AVFoundation
import SnapKit
import Photos

class RecordVideoViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "系统相机", style: .done, target: self, action: #selector(recordVideo))
    }
    
    @objc func recordVideo() {
        
        /// 判断是否支持录像
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
            if let availableMediaTypes = UIImagePickerController.availableMediaTypes(for: UIImagePickerController.SourceType.camera) {
                print(availableMediaTypes)
                if !availableMediaTypes.contains("public.movie") {
                    print("不支持录像")
                    return
                }
            }
        }
        
        /// 视频权限
        AVCaptureDevice.requestAccess(for: AVMediaType.video) {[weak self] (granted) in
            guard let weakSelf = self else {
                return
            }
            if !granted {
                print("无权限访问相机")
                weakSelf.closePage()
                return
            }

            // 录音权限
            AVCaptureDevice.requestAccess(for: AVMediaType.audio) {[weak self] (granted) in
                guard let weakSelf = self else {
                    return
                }

                if !granted {
                    print("无权限访问麦克风")
                    weakSelf.closePage()
                    return
                }
                // 进入录像页面
                DispatchQueue.main.async {
                    weakSelf.present(weakSelf.pickerController, animated: true, completion: nil)
                }
            }
        }
        
        
    }
    
    //MARK:关闭页面
    func closePage() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    ///
    lazy var pickerController: UIImagePickerController = {
        let pickerController = UIImagePickerController()
        // 设置图像选取控制器的来源模式为相机模式 相机、相册
        pickerController.sourceType = UIImagePickerController.SourceType.camera
        // 设置相机的类型 public.image  public.movie
        pickerController.mediaTypes = ["public.movie",]
        // 设置摄像头 前、后
        pickerController.cameraDevice = UIImagePickerController.CameraDevice.rear;
        // 设置摄像头闪光灯模式
//        pickerController.cameraFlashMode = UIImagePickerController.CameraFlashMode.auto
        
        // 设置摄像图像品质
        pickerController.videoQuality = UIImagePickerController.QualityType.typeHigh
        // 设置最长摄像时间
        pickerController.videoMaximumDuration = 30
        // 允许用户进行编辑
        pickerController.allowsEditing = false
        // 设置委托对象
        pickerController.delegate = self
        return pickerController
    }()
}

extension RecordVideoViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let mediaType = info[UIImagePickerController.InfoKey.mediaType] as! String

        if mediaType == "public.movie" {
            // 获取视频文件的url
            let mediaURL = info[UIImagePickerController.InfoKey.mediaURL] as! NSURL
            // 视频文件的地址
            let pathString = mediaURL.relativePath
            print("视频地址：" + pathString!)
            
            DispatchQueue.global().async {
                //判断能不能保存到相簿
                if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(pathString!)) {
                    //保存视频到相簿
                    UISaveVideoAtPathToSavedPhotosAlbum(pathString!, self,  #selector(self.saveVideo(videoPath:didFinishSavingWithError:contextInfo:)), nil)
                }
                DispatchQueue.main.async {
                    picker.dismiss(animated: true, completion: nil)
                }
            }
            
        }
    }
    
    @objc private func saveVideo(videoPath:String, didFinishSavingWithError error: NSError?, contextInfo: AnyObject) {
        if error != nil{
            print("保存视频 失败")
        }else{
            print("保存视频 成功")
        }
    }
}
