//
//  VideoMergeViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit
import  AVFoundation

// 多视频合成
class VideoMergeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "开始合成", style: .done, target: self, action: #selector(starMerge))
    }
    
    @objc func starMerge() {
        let videoPaths = [
            "1619163716.mp4",
            "1619163734.mp4",
            "1619163741.mp4"
        ]
        
        for i in 0..<videoPaths.count {
            if !FileManager.default.fileExists(atPath: videoPaths[i]) {
                print("文件不存在，请先拍照，再修改视频地址")
                return
            }
        }
        
        print("==> 源文件")
        for i in 0..<videoPaths.count {
            print("==> 第 \(i) 个文件")
            self.getVideoSize(videoUrl: URL(fileURLWithPath: videoPaths[i]))
            self.getVideoLength(videoUrl: URL(fileURLWithPath: videoPaths[i]))
        }
        
        print("==> 开始合并")
        
        let outputPath = self.getNewPath(videoTyle: AVFileType.mp4)
        print(outputPath)
        self.mergeVideo(videoPaths: videoPaths, outputPath: outputPath) { (success) in
            if success {
                print("多视频合成 成功")
            }else{
                print("多视频合成 失败")
            }
        }
    }
    
    //MARK: 多视频合成
    func mergeVideo(videoPaths:[String], outputPath:String, completeHandler:@escaping (Bool)->()) {
        if videoPaths.count < 2 {
            return
        }
        
        let mixComposition = AVMutableComposition()
        //音频轨道
        let audioTrack = mixComposition.addMutableTrack(withMediaType: AVMediaType.audio, preferredTrackID: kCMPersistentTrackID_Invalid)
        
        //视频轨道
        let videoTrack = mixComposition.addMutableTrack(withMediaType: AVMediaType.video, preferredTrackID: kCMPersistentTrackID_Invalid)
        
        var totalDuration = CMTime.zero
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        
        for i in 0 ..< videoPaths.count {
            let pathUrl = documentsDirectory + "/\(videoPaths[i])"
            if !FileManager.default.fileExists(atPath: pathUrl) {
                print("文件不存在")
                break
            }
            
            let asset = AVURLAsset.init(url: URL(fileURLWithPath: pathUrl))
            // 获取AVAsset中的音频
            let assetAudioTracks = asset.tracks(withMediaType: AVMediaType.audio)
            if assetAudioTracks.count == 0 {
                print("未获取到音频")
                break
            }
            // 向通道内加入音频
            try! audioTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: asset.duration), of: assetAudioTracks.first!, at: totalDuration)
            
            // 获取AVAsset中的视频
            let assetVideoTracks = asset.tracks(withMediaType: AVMediaType.video)
            if assetVideoTracks.count == 0 {
                print("未获取到视频")
                break
            }
            // 向通道内加入视频
            try! videoTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: asset.duration), of: assetVideoTracks.first!, at: totalDuration)
            totalDuration = CMTimeAdd(totalDuration, asset.duration)
        }
        
        // 导出合成后的视频
        let outputURL = URL(fileURLWithPath: outputPath)
        let avAssetExportSession = AVAssetExportSession.init(asset: mixComposition, presetName: AVAssetExportPresetMediumQuality)
        avAssetExportSession?.outputURL = outputURL
        avAssetExportSession?.outputFileType = .mp4
        avAssetExportSession?.shouldOptimizeForNetworkUse = true
        avAssetExportSession?.exportAsynchronously {
            switch avAssetExportSession?.status {
            
            case .unknown:
                print("AVAssetExportSessionStatusUnknown")
                break
            case .waiting:
                print("AVAssetExportSessionStatusWaiting")
                break

            case .exporting:
                print("AVAssetExportSessionStatusExporting")
                break

            case .completed:
                print("AVAssetExportSessionStatusCompleted")
                self.getVideoSize(videoUrl: outputURL)
                self.getVideoLength(videoUrl: outputURL)
                completeHandler(true)
                break

            case .failed:
                print("AVAssetExportSessionStatusFailed")
                completeHandler(false)
                break

            case .cancelled:
                print("AVAssetExportSessionStatusCancelled")
                completeHandler(false)
                break

            default:
                break
            }
        }
    }
    
    //MARK: 获取视频时长（秒数）
    func getVideoLength(videoUrl: URL) {
        let avUrlAsset = AVURLAsset.init(url: videoUrl)
        let cmtime = avUrlAsset.duration
        let second = Int(cmtime.seconds)
        
        print("视频秒数 == \(second)")
    }
    
    //MARK: 获取视频文件大小//文件属性
    func getVideoSize(videoUrl: URL) {
        let path = videoUrl.path
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path) {
            let fileDic = try! fileManager.attributesOfItem(atPath: path)
            print("文件属性")
            print(fileDic)
            let size = fileDic[FileAttributeKey(rawValue: "NSFileSize")] as? Int ?? 0
            print("\(size)B")
            print("\(size/1024)KB")
            let sizeM = String(format: "%.2f", Float(size)/1024/1024)
            print(sizeM + "M")
            
        }else{
            print("文件不存在")
        }
    }
    
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }

}
