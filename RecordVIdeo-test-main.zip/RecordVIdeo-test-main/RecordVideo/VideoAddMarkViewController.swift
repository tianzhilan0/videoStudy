//
//  VideoAddMarkViewController.swift
//  RecordVideo
//
//  Created by Admin on 2021/4/23.
//

import UIKit
import AVFoundation

/// 视频添加水印
class VideoAddMarkViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white

        self.navigationItem.rightBarButtonItems = [
            UIBarButtonItem.init(title: "图片水印", style: .done, target: self, action: #selector(starAddImage)),
            UIBarButtonItem.init(title: "文字水印", style: .done, target: self, action: #selector(starAddTitle))
        ]
    }
    
    @objc func starAddImage() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619343879.mp4"
        
        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        
        
        let outputPath = self.getNewPath(videoTyle: AVFileType.mp4)
        print(outputPath)

        self.videoAddMark(imageName: "good", title: nil, inputPath: videoPath, outputPath: outputPath) { (success) in
            if success {
                print("添加水印 成功")
            }else{
                print("添加水印 失败")
            }
        }
    }
    
    @objc func starAddTitle() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let videoPath = documentsDirectory + "/" + "1619343879.mp4"
        
        
        if !FileManager.default.fileExists(atPath: videoPath) {
            print("文件不存在，请先拍照，再修改视频地址")
            return
        }
        
        
        let outputPath = self.getNewPath(videoTyle: AVFileType.mp4)
        print(outputPath)
        self.videoAddMark(imageName: nil, title: "尚德机构", inputPath: videoPath, outputPath: outputPath) { (success) in
            if success {
                print("添加水印 成功")
            }else{
                print("添加水印 失败")
            }
        }
    }
    
    //添加水印
    func videoAddMark(imageName:String?, title:String?, inputPath:String, outputPath:String, completeHandler:@escaping (Bool)->()) {
        
        //创建AVAsset实例
        let videoAsset = AVURLAsset.init(url: URL(fileURLWithPath: inputPath))
        
        let mixComposition = AVMutableComposition()
        //音频轨道
        let audioTrack = mixComposition.addMutableTrack(withMediaType: AVMediaType.audio, preferredTrackID: kCMPersistentTrackID_Invalid)
        // 获取AVAsset中的音频
        let assetAudioTracks = videoAsset.tracks(withMediaType: AVMediaType.audio)
        if assetAudioTracks.count == 0 {
            print("未获取到音频")
            return
        }
        // 向通道内加入音频
        try! audioTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration), of: assetAudioTracks.first!, at: CMTime.zero)
        
        //视频轨道
        let videoTrack = mixComposition.addMutableTrack(withMediaType: AVMediaType.video, preferredTrackID: kCMPersistentTrackID_Invalid)
        // 获取AVAsset中的视频
        let assetVideoTracks = videoAsset.tracks(withMediaType: AVMediaType.video)
        if assetVideoTracks.count == 0 {
            print("未获取到视频")
            return
        }
        // 向通道内加入视频
        try! videoTrack?.insertTimeRange(CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration), of: assetVideoTracks.first!, at: CMTime.zero)
        
        //1 AVMutableVideoCompositionInstruction 视频轨道中的一个视频，可以缩放、旋转等
        let mainInstruction = AVMutableVideoCompositionInstruction()
        mainInstruction.timeRange = CMTimeRangeMake(start: CMTime.zero, duration: videoAsset.duration)
        
        // 2 AVMutableVideoCompositionLayerInstruction 一个视频轨道，包含了这个轨道上的所有视频素材
        let videolayerInstruction = AVMutableVideoCompositionLayerInstruction.init(assetTrack: videoTrack!)

        let videoTransform = (assetVideoTracks.first?.preferredTransform)!
        var isVideoAssetPortrait = true
        var naturalSize = (assetVideoTracks.first?.naturalSize)!

        if videoTransform.a == 0,
           videoTransform.b == 1,
           videoTransform.c == -1,
           videoTransform.d == 0
           {
            isVideoAssetPortrait = true
            
        } else if videoTransform.a == 0,
                 videoTransform.b == -1,
                 videoTransform.c == 1,
                 videoTransform.d == 0 {
            isVideoAssetPortrait = true
        } else if videoTransform.a == 1,
                  videoTransform.b == 0,
                  videoTransform.c == 0,
                  videoTransform.d == 1 {
             isVideoAssetPortrait = false
         } else if videoTransform.a == -1,
                   videoTransform.b == 0,
                   videoTransform.c == 0,
                   videoTransform.d == -1 {
              isVideoAssetPortrait = false
          }
//        videolayerInstruction.setTransform(CGAffineTransform(rotationAngle: 0), at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(rotationAngle: CGFloat(Double.pi / 2.0)), at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(rotationAngle: CGFloat(Double.pi)), at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(rotationAngle: CGFloat(Double.pi / 2.0)), at: CMTime.zero)
        videolayerInstruction.setTransform(videoTransform, at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(a: 0, b: 1, c: -1, d: 0, tx: 0, ty: 0), at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(a: 0, b: -1, c: 1, d: 0, tx: 0, ty: 0), at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(a: 1, b: 0, c: 0, d: 1, tx: 0, ty: 0), at: CMTime.zero)
//        videolayerInstruction.setTransform(CGAffineTransform(a: -1, b: 0, c: 0, d: -1, tx: 0, ty: 0), at: CMTime.zero)
        
        // 3 - Add instructions
        mainInstruction.layerInstructions = [videolayerInstruction]

        //AVMutableVideoComposition：管理所有视频轨道，水印添加就在这上面
        let mainCompositionInst = AVMutableVideoComposition()
        
        if isVideoAssetPortrait {
            naturalSize = CGSize(width: naturalSize.height, height: naturalSize.width)
        }
        let width = naturalSize.width
        let height = naturalSize.height
        mainCompositionInst.renderSize = CGSize.init(width: width, height: height)
        mainCompositionInst.instructions = [mainInstruction]
        mainCompositionInst.frameDuration = CMTimeMake(value: 1, timescale: 30)
                
        if title == nil && (imageName == nil || UIImage(named: imageName!) == nil) {
            completeHandler(false)
            return
        }
        
        let overlayLayer = CALayer()

        if title != nil {
            // 文字
            let subtitle1Text = CATextLayer()
            subtitle1Text.font = "Helvetica-Bold" as CFTypeRef
            subtitle1Text.fontSize = 40
            subtitle1Text.frame = CGRect(x: width/2-100, y: height/2-60, width: 200, height: 120)
            subtitle1Text.string = title
            subtitle1Text.alignmentMode = .center
            subtitle1Text.foregroundColor = UIColor.white.cgColor
            overlayLayer.addSublayer(subtitle1Text)
        }
        if imageName != nil, let image = UIImage(named: imageName!) {
            //图片
            let picLayer = CALayer()
            picLayer.contents = image.cgImage
            picLayer.frame = CGRect(x: width/2-80, y: height/2-80, width: 160, height: 160)
            overlayLayer.addSublayer(picLayer)
        }
        
        overlayLayer.frame = CGRect(x: 0, y: 0, width: width, height: height)
        overlayLayer.masksToBounds = true
        
        let parentLayer = CALayer()
        let videoLayer = CALayer()
        parentLayer.frame = CGRect(x: 0, y: 0, width: width, height: height)
        videoLayer.frame = CGRect(x: 0, y: 0, width: width, height: height)
        parentLayer.addSublayer(videoLayer)
        parentLayer.addSublayer(overlayLayer)
        mainCompositionInst.animationTool = AVVideoCompositionCoreAnimationTool.init(postProcessingAsVideoLayer: videoLayer, in: parentLayer)
        
        // 导出合成后的视频
        let outputURL = URL(fileURLWithPath: outputPath)
        let avAssetExportSession = AVAssetExportSession.init(asset: mixComposition, presetName: AVAssetExportPresetMediumQuality)
        avAssetExportSession?.outputURL = outputURL
        avAssetExportSession?.outputFileType = .mp4
        avAssetExportSession?.shouldOptimizeForNetworkUse = true
        avAssetExportSession?.videoComposition = mainCompositionInst;

        avAssetExportSession?.exportAsynchronously {
            switch avAssetExportSession?.status {
            
            case .unknown:
                print("AVAssetExportSessionStatusUnknown")
                break
            case .waiting:
                print("AVAssetExportSessionStatusWaiting")
                break

            case .exporting:
                print("AVAssetExportSessionStatusExporting")
                break

            case .completed:
                print("AVAssetExportSessionStatusCompleted")
                self.getVideoSize(videoUrl: outputURL)
                self.getVideoLength(videoUrl: outputURL)
                completeHandler(true)
                break

            case .failed:
                print("AVAssetExportSessionStatusFailed")
                completeHandler(false)
                break

            case .cancelled:
                print("AVAssetExportSessionStatusCancelled")
                completeHandler(false)
                break

            default:
                break
            }
        }
    }
    
    //MARK: 获取视频时长（秒数）
    func getVideoLength(videoUrl: URL) {
        let avUrlAsset = AVURLAsset.init(url: videoUrl)
        let cmtime = avUrlAsset.duration
        let second = Int(cmtime.seconds)
        
        print("视频秒数 == \(second)")
    }
    
    //MARK: 获取视频文件大小//文件属性
    func getVideoSize(videoUrl: URL) {
        let path = videoUrl.path
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path) {
            let fileDic = try! fileManager.attributesOfItem(atPath: path)
            print("文件属性")
            print(fileDic)
            let size = fileDic[FileAttributeKey(rawValue: "NSFileSize")] as? Int ?? 0
            print("\(size)B")
            print("\(size/1024)KB")
            let sizeM = String(format: "%.2f", Float(size)/1024/1024)
            print(sizeM + "M")
            
        }else{
            print("文件不存在")
        }
    }
    
    //MARK: 获取一个新的沙盒存储地址
    /// 获取一个新的沙盒存储地址
    /// - Returns: <#description#>
    func getNewPath(videoTyle: AVFileType) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true )
        let documentsDirectory = paths[0]  as  String
        let timeInterval = Int(Date().timeIntervalSince1970)
        var filePath = "\(documentsDirectory)/\(timeInterval)"

        switch videoTyle {
        case .mp4:
            filePath = filePath + ".mp4"
            break
        case .mov:
            filePath = filePath + ".mov"
            break
        default:
            filePath = filePath + ".mp4"
            break
        }
        
        return filePath
    }

}
